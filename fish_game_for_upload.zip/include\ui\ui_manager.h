#pragma once

#include "panel.h"
#include "button.h"
#include "label.h"
#include <memory>
#include <stack>

class UIManager {
public:
    static UIManager& Instance();
    
    bool Initialize(SDL_Renderer* renderer);
    void Shutdown();
    
    // UI状态管理
    void PushScreen(std::shared_ptr<Panel> screen);
    void PopScreen();
    void ClearScreens();
    
    // 事件处理
    bool HandleEvent(const SDL_Event& event);
    void Update(float deltaTime);
    void Render(SDL_Renderer* renderer);
    
    // 创建UI元素的工厂方法
    std::shared_ptr<Button> CreateButton(int x, int y, int width, int height, const std::string& text);
    std::shared_ptr<Label> CreateLabel(int x, int y, const std::string& text);
    std::shared_ptr<Panel> CreatePanel(int x, int y, int width, int height);
    
    // 创建预定义的UI界面
    std::shared_ptr<Panel> CreateMainMenu();
    std::shared_ptr<Panel> CreateGameHUD();
    std::shared_ptr<Panel> CreatePauseMenu();
    std::shared_ptr<Panel> CreateRankingBoard();

private:
    UIManager() = default;
    ~UIManager() = default;
    
    SDL_Renderer* mRenderer;
    std::stack<std::shared_ptr<Panel>> mScreens;
    bool mInitialized;
}; 