#pragma once

#include <SDL2/SDL.h>
#include <string>
#include <functional>
#include <memory>

class UIElement {
public:
    UIElement(int x, int y, int width, int height);
    virtual ~UIElement() = default;

    // 基础属性
    void SetPosition(int x, int y) { mX = x; mY = y; }
    void SetSize(int width, int height) { mWidth = width; mHeight = height; }
    void SetVisible(bool visible) { mIsVisible = visible; }
    bool IsVisible() const { return mIsVisible; }

    // 事件处理
    virtual bool HandleEvent(const SDL_Event& event);
    virtual void Update(float deltaTime);
    virtual void Render(SDL_Renderer* renderer);

    // 碰撞检测
    bool ContainsPoint(int x, int y) const;

protected:
    int mX, mY;
    int mWidth, mHeight;
    bool mIsVisible;
    bool mIsHovered;
    bool mIsPressed;
}; 