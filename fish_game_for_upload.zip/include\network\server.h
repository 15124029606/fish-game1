#pragma once

#include <vector>
#include <unordered_map>
#include <memory>
#include <sys/epoll.h>
#include "protocol.h"

class GameServer {
public:
    GameServer(int port = 8888);
    ~GameServer();

    bool Initialize();
    void Run();
    void Shutdown();

private:
    // 网络事件处理
    void HandleNewConnection();
    void HandleClientMessage(int clientFd);
    void DisconnectClient(int clientFd);
    
    // 游戏逻辑处理
    void BroadcastGameState();
    void UpdateGameState();
    
    // 进程池管理
    void InitProcessPool();
    void AssignClientToProcess(int clientFd);
    
    // 共享内存管理
    void InitSharedMemory();
    void UpdateRankingBoard();

private:
    int mPort;
    int mServerFd;
    int mEpollFd;
    bool mIsRunning;
    
    static const int MAX_EVENTS = 10000;
    static const int PROCESS_POOL_SIZE = 10;
    static const int MAX_CLIENTS_PER_PROCESS = 200;
    
    struct epoll_event mEvents[MAX_EVENTS];
    std::unordered_map<int, std::shared_ptr<ClientSession>> mClients;
    
    // 共享内存相关
    void* mSharedMemory;
    int mSharedMemoryFd;
}; 