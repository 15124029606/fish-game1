#include "entity.h"
#include <algorithm>

Entity::Entity()
    : mType(EntityType::PLAYER)
    , mX(0.0f)
    , mY(0.0f)
    , mVelX(0.0f)
    , mVelY(0.0f)
    , mWidth(32.0f)
    , mHeight(32.0f)
    , mTexture(nullptr)
{
}

SDL_Rect Entity::GetCollisionBox() const {
    return SDL_Rect{
        static_cast<int>(mX - mWidth/2),
        static_cast<int>(mY - mHeight/2),
        static_cast<int>(mWidth),
        static_cast<int>(mHeight)
    };
}

bool Entity::CollidesWith(const Entity* other) const {
    if (!other) return false;
    
    SDL_Rect myBox = GetCollisionBox();
    SDL_Rect otherBox = other->GetCollisionBox();
    
    return SDL_HasIntersection(&myBox, &otherBox) == SDL_TRUE;
}

void Entity::Update(float deltaTime) {
    // 基础物理更新
    mX += mVelX * deltaTime;
    mY += mVelY * deltaTime;
    
    // 确保实体不会移出屏幕
    mX = std::clamp(mX, mWidth/2, 1280.0f - mWidth/2);  // 1280是屏幕宽度
    mY = std::clamp(mY, mHeight/2, 720.0f - mHeight/2); // 720是屏幕高度
}

void Entity::Render(SDL_Renderer* renderer) {
    if (!renderer) return;
    
    if (mTexture) {
        SDL_Rect destRect = GetCollisionBox();
        SDL_RenderCopy(renderer, mTexture, nullptr, &destRect);
    } else {
        // 如果没有贴图,绘制一个简单的矩形
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_Rect rect = GetCollisionBox();
        SDL_RenderFillRect(renderer, &rect);
    }
} 