#include "ui/button.h"
#include <SDL2/SDL_ttf.h>

Button::Button(int x, int y, int width, int height, const std::string& text)
    : UIElement(x, y, width, height)
    , mText(text)
{
    // 设置默认颜色
    mNormalColor = {100, 100, 100, 255};  // 灰色
    mHoverColor = {150, 150, 150, 255};   // 浅灰色
    mPressedColor = {50, 50, 50, 255};    // 深灰色
}

void Button::SetColors(SDL_Color normal, SDL_Color hover, SDL_Color pressed) {
    mNormalColor = normal;
    mHoverColor = hover;
    mPressedColor = pressed;
}

bool Button::HandleEvent(const SDL_Event& event) {
    bool handled = UIElement::HandleEvent(event);
    
    if (handled && event.type == SDL_MOUSEBUTTONUP) {
        if (mIsHovered && mOnClick) {
            mOnClick();
        }
    } else if (handled && event.type == SDL_MOUSEMOTION) {
        if (mIsHovered && mOnHover) {
            mOnHover();
        }
    }
    
    return handled;
}

void Button::Render(SDL_Renderer* renderer) {
    if (!mIsVisible) return;
    
    // 选择当前状态的颜色
    SDL_Color currentColor = mNormalColor;
    if (mIsPressed) {
        currentColor = mPressedColor;
    } else if (mIsHovered) {
        currentColor = mHoverColor;
    }
    
    // 绘制按钮背景
    SDL_SetRenderDrawColor(renderer, 
        currentColor.r, currentColor.g, 
        currentColor.b, currentColor.a);
    
    SDL_Rect rect = {mX, mY, mWidth, mHeight};
    SDL_RenderFillRect(renderer, &rect);
    
    // 绘制按钮边框
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderDrawRect(renderer, &rect);
    
    // 绘制文本
    if (!mText.empty()) {
        // 注意：这里需要TTF_Font*对象来渲染文本
        // 在实际应用中，应该通过ResourceManager来管理字体资源
        TTF_Font* font = TTF_OpenFont("assets/fonts/default.ttf", 16);
        if (font) {
            SDL_Color textColor = {0, 0, 0, 255};  // 黑色文本
            SDL_Surface* surface = TTF_RenderText_Blended(font, mText.c_str(), textColor);
            if (surface) {
                SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
                if (texture) {
                    // 计算文本位置（居中）
                    int textWidth = surface->w;
                    int textHeight = surface->h;
                    SDL_Rect textRect = {
                        mX + (mWidth - textWidth) / 2,
                        mY + (mHeight - textHeight) / 2,
                        textWidth,
                        textHeight
                    };
                    
                    SDL_RenderCopy(renderer, texture, nullptr, &textRect);
                    SDL_DestroyTexture(texture);
                }
                SDL_FreeSurface(surface);
            }
            TTF_CloseFont(font);
        }
    }
} 