#pragma once

#include <string>
#include "entity.h"

enum class Rank {
    INTERN,     // 实习生
    MANAGER,    // 经理
    CEO        // CEO
};

class Player : public Entity {
public:
    Player(const std::string& name);
    virtual ~Player() = default;

    // 基础属性
    void SetRank(Rank rank) { mRank = rank; }
    Rank GetRank() const { return mRank; }
    void AddMoney(int amount) { mMoney += amount; }
    void AddEnergy(int amount) { mEnergy = std::min(mEnergy + amount, MAX_ENERGY); }
    
    // 状态检查
    bool CanShoot() const { return mEnergy > 0; }
    bool IsMovementReduced() const { return mEnergy < (MAX_ENERGY / 4); }
    
    // 动作
    void Shoot();
    void Move(float dx, float dy);
    void Update(float deltaTime) override;

private:
    std::string mName;
    Rank mRank;
    int mMoney;
    int mEnergy;
    float mShootCooldown;
    
    // 常量
    static const int MAX_ENERGY = 100;
    static const float SHOOT_COOLDOWN_INTERN = 0.5f;    // 实习生射击冷却
    static const float SHOOT_COOLDOWN_MANAGER = 0.2f;   // 经理射击冷却
    static const float SHOOT_COOLDOWN_CEO = 0.1f;       // CEO射击冷却
}; 