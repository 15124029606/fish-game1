# 摸鱼射击游戏

一个基于SDL2的多人在线射击游戏，以办公室摸鱼为主题。

## 依赖项

- SDL2
- CMake 3.10+
- C++17 编译器
- Linux系统（用于多进程和共享内存支持）

## 编译和运行

1. 安装依赖：
```bash
# Ubuntu/Debian
sudo apt-get install libsdl2-dev cmake build-essential

# CentOS/RHEL
sudo yum install SDL2-devel cmake gcc-c++
```

2. 编译：
```bash
mkdir build
cd build
cmake ..
make
```

3. 运行：
```bash
# 运行服务器
./fish_game_server

# 运行客户端
./fish_game
```

## 游戏说明

- WASD或方向键移动
- 鼠标左键射击
- ESC打开菜单

### 游戏目标

1. 射击项目（蓝色方块）获得金钱
2. 攻击老板（西装小人）提升职级
3. 捕捉鱼群（游动图标）恢复体力

### 职级系统

- 实习生：单发子弹
- 经理：三连发+自动追踪
- CEO：全屏AOE伤害

## 开发计划

- [x] 基础游戏框架
- [x] 实体系统
- [x] 网络框架
- [ ] 资源管理
- [ ] UI系统
- [ ] 排行榜系统
- [ ] 反作弊系统 