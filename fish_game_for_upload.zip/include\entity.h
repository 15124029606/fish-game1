#pragma once

#include <SDL2/SDL.h>

enum class EntityType {
    PLAYER,
    PROJECT,    // 项目（蓝色方块）
    BOSS,       // 老板（西装小人）
    FISH        // 鱼群
};

class Entity {
public:
    Entity();
    virtual ~Entity() = default;

    // 基础属性
    void SetPosition(float x, float y) { mX = x; mY = y; }
    float GetX() const { return mX; }
    float GetY() const { return mY; }
    void SetVelocity(float vx, float vy) { mVelX = vx; mVelY = vy; }
    EntityType GetType() const { return mType; }

    // 碰撞检测
    SDL_Rect GetCollisionBox() const;
    bool CollidesWith(const Entity* other) const;

    // 更新逻辑
    virtual void Update(float deltaTime);
    virtual void Render(SDL_Renderer* renderer);

protected:
    EntityType mType;
    float mX, mY;          // 位置
    float mVelX, mVelY;    // 速度
    float mWidth, mHeight; // 碰撞箱尺寸
    SDL_Texture* mTexture; // 贴图
}; 