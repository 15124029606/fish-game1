#pragma once

#include <cstdint>
#include <string>
#include <vector>

// 网络消息类型
enum class MessageType : uint8_t {
    // 连接相关
    CONNECT_REQUEST,
    CONNECT_RESPONSE,
    DISCONNECT,
    PING,
    PONG,
    
    // 游戏状态
    PLAYER_JOIN,
    PLAYER_LEAVE,
    PLAYER_MOVE,
    PLAYER_SHOOT,
    PLAYER_HIT,
    
    // 实体状态
    ENTITY_SPAWN,
    ENTITY_DESTROY,
    ENTITY_UPDATE,
    
    // 资源变更
    MONEY_CHANGE,
    ENERGY_CHANGE,
    RANK_CHANGE,
    
    // 排行榜
    RANKING_UPDATE
};

// 基础消息结构
struct NetworkMessage {
    MessageType type;
    uint32_t sequence;  // 消息序号,用于可靠性保证
    uint32_t timestamp; // 时间戳,用于延迟补偿
    std::vector<uint8_t> payload;
};

// 客户端会话
class ClientSession {
public:
    ClientSession(int fd);
    ~ClientSession();

    bool SendMessage(const NetworkMessage& msg);
    bool ReceiveMessage(NetworkMessage& msg);
    
    int GetFileDescriptor() const { return mFd; }
    uint32_t GetLastPingTime() const { return mLastPingTime; }
    void UpdatePingTime() { mLastPingTime = GetCurrentTimestamp(); }

private:
    static uint32_t GetCurrentTimestamp();
    
    int mFd;
    uint32_t mLastPingTime;
    uint32_t mNextSequence;
    std::vector<uint8_t> mReceiveBuffer;
};

// 序列化/反序列化工具
namespace Protocol {
    // 基础类型序列化
    void WriteBool(std::vector<uint8_t>& buffer, bool value);
    void WriteInt32(std::vector<uint8_t>& buffer, int32_t value);
    void WriteFloat(std::vector<uint8_t>& buffer, float value);
    void WriteString(std::vector<uint8_t>& buffer, const std::string& value);
    
    // 基础类型反序列化
    bool ReadBool(const std::vector<uint8_t>& buffer, size_t& offset);
    int32_t ReadInt32(const std::vector<uint8_t>& buffer, size_t& offset);
    float ReadFloat(const std::vector<uint8_t>& buffer, size_t& offset);
    std::string ReadString(const std::vector<uint8_t>& buffer, size_t& offset);
    
    // 消息封装
    NetworkMessage CreateMessage(MessageType type, const std::vector<uint8_t>& payload);
    bool ParseMessage(const std::vector<uint8_t>& buffer, NetworkMessage& msg);
} 