#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "ui/ui_manager.h"
#include <iostream>

class UITest {
public:
    bool Initialize() {
        // 初始化SDL
        if (SDL_Init(SDL_INIT_VIDEO) < 0) {
            std::cerr << "SDL初始化失败: " << SDL_GetError() << std::endl;
            return false;
        }
        
        // 创建窗口
        mWindow = SDL_CreateWindow(
            "UI测试",
            SDL_WINDOWPOS_CENTERED,
            SDL_WINDOWPOS_CENTERED,
            1280,
            720,
            SDL_WINDOW_SHOWN
        );
        
        if (!mWindow) {
            std::cerr << "窗口创建失败: " << SDL_GetError() << std::endl;
            return false;
        }
        
        // 创建渲染器
        mRenderer = SDL_CreateRenderer(
            mWindow,
            -1,
            SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
        );
        
        if (!mRenderer) {
            std::cerr << "渲染器创建失败: " << SDL_GetError() << std::endl;
            return false;
        }
        
        // 初始化UI管理器
        if (!UIManager::Instance().Initialize(mRenderer)) {
            std::cerr << "UI管理器初始化失败" << std::endl;
            return false;
        }
        
        // 创建测试UI
        CreateTestUI();
        
        return true;
    }
    
    void Run() {
        bool isRunning = true;
        SDL_Event event;
        
        while (isRunning) {
            // 处理事件
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    isRunning = false;
                }
                
                UIManager::Instance().HandleEvent(event);
            }
            
            // 更新
            UIManager::Instance().Update(1.0f / 60.0f);
            
            // 渲染
            SDL_SetRenderDrawColor(mRenderer, 45, 45, 45, 255);
            SDL_RenderClear(mRenderer);
            
            UIManager::Instance().Render(mRenderer);
            
            SDL_RenderPresent(mRenderer);
        }
    }
    
    void Shutdown() {
        UIManager::Instance().Shutdown();
        
        if (mRenderer) {
            SDL_DestroyRenderer(mRenderer);
            mRenderer = nullptr;
        }
        
        if (mWindow) {
            SDL_DestroyWindow(mWindow);
            mWindow = nullptr;
        }
        
        SDL_Quit();
    }

private:
    void CreateTestUI() {
        // 创建并显示主菜单
        auto mainMenu = UIManager::Instance().CreateMainMenu();
        UIManager::Instance().PushScreen(mainMenu);
        
        // 创建并显示HUD（叠加在主菜单上方以展示多层UI）
        auto hud = UIManager::Instance().CreateGameHUD();
        UIManager::Instance().PushScreen(hud);
    }

private:
    SDL_Window* mWindow;
    SDL_Renderer* mRenderer;
};

int main(int argc, char* argv[]) {
    UITest test;
    
    if (!test.Initialize()) {
        return 1;
    }
    
    test.Run();
    test.Shutdown();
    
    return 0;
} 