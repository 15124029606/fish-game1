#include "ui/ui_manager.h"
#include <SDL2/SDL_ttf.h>

UIManager& UIManager::Instance() {
    static UIManager instance;
    return instance;
}

bool UIManager::Initialize(SDL_Renderer* renderer) {
    if (mInitialized) return true;
    
    mRenderer = renderer;
    
    // 初始化SDL_ttf
    if (TTF_Init() < 0) {
        return false;
    }
    
    mInitialized = true;
    return true;
}

void UIManager::Shutdown() {
    ClearScreens();
    TTF_Quit();
    mInitialized = false;
}

void UIManager::PushScreen(std::shared_ptr<Panel> screen) {
    if (screen) {
        mScreens.push(screen);
    }
}

void UIManager::PopScreen() {
    if (!mScreens.empty()) {
        mScreens.pop();
    }
}

void UIManager::ClearScreens() {
    while (!mScreens.empty()) {
        mScreens.pop();
    }
}

bool UIManager::HandleEvent(const SDL_Event& event) {
    if (mScreens.empty()) return false;
    return mScreens.top()->HandleEvent(event);
}

void UIManager::Update(float deltaTime) {
    if (mScreens.empty()) return;
    mScreens.top()->Update(deltaTime);
}

void UIManager::Render(SDL_Renderer* renderer) {
    // 从底到顶渲染所有界面
    std::vector<std::shared_ptr<Panel>> screens;
    auto tempStack = mScreens;
    
    while (!tempStack.empty()) {
        screens.push_back(tempStack.top());
        tempStack.pop();
    }
    
    for (auto it = screens.rbegin(); it != screens.rend(); ++it) {
        (*it)->Render(renderer);
    }
}

std::shared_ptr<Button> UIManager::CreateButton(int x, int y, int width, int height, const std::string& text) {
    return std::make_shared<Button>(x, y, width, height, text);
}

std::shared_ptr<Label> UIManager::CreateLabel(int x, int y, const std::string& text) {
    return std::make_shared<Label>(x, y, text);
}

std::shared_ptr<Panel> UIManager::CreatePanel(int x, int y, int width, int height) {
    return std::make_shared<Panel>(x, y, width, height);
}

std::shared_ptr<Panel> UIManager::CreateMainMenu() {
    auto menu = CreatePanel(0, 0, 1280, 720);
    menu->SetBackgroundColor({0, 0, 0, 200});
    
    // 创建标题
    auto title = CreateLabel(640, 100, "摸鱼射击游戏");
    title->SetFontSize(48);
    title->SetAlignment(Label::ALIGN_CENTER);
    menu->AddElement(title);
    
    // 创建按钮
    auto startButton = CreateButton(540, 300, 200, 50, "开始游戏");
    startButton->SetOnClick([]() {
        // 处理开始游戏
    });
    menu->AddElement(startButton);
    
    auto rankButton = CreateButton(540, 370, 200, 50, "排行榜");
    rankButton->SetOnClick([]() {
        // 显示排行榜
    });
    menu->AddElement(rankButton);
    
    auto exitButton = CreateButton(540, 440, 200, 50, "退出");
    exitButton->SetOnClick([]() {
        // 退出游戏
    });
    menu->AddElement(exitButton);
    
    return menu;
}

std::shared_ptr<Panel> UIManager::CreateGameHUD() {
    auto hud = CreatePanel(0, 0, 1280, 720);
    hud->SetBackgroundColor({0, 0, 0, 0});  // 完全透明
    
    // 创建状态显示
    auto moneyLabel = CreateLabel(10, 10, "金钱: 0");
    hud->AddElement(moneyLabel);
    
    auto energyLabel = CreateLabel(10, 40, "体力: 100");
    hud->AddElement(energyLabel);
    
    auto rankLabel = CreateLabel(10, 70, "职级: 实习生");
    hud->AddElement(rankLabel);
    
    // 创建暂停按钮
    auto pauseButton = CreateButton(1200, 10, 70, 30, "暂停");
    pauseButton->SetOnClick([]() {
        // 显示暂停菜单
    });
    hud->AddElement(pauseButton);
    
    return hud;
}

std::shared_ptr<Panel> UIManager::CreatePauseMenu() {
    auto menu = CreatePanel(440, 210, 400, 300);
    menu->SetBackgroundColor({200, 200, 200, 230});
    
    auto title = CreateLabel(640, 240, "游戏暂停");
    title->SetAlignment(Label::ALIGN_CENTER);
    title->SetFontSize(24);
    menu->AddElement(title);
    
    auto resumeButton = CreateButton(540, 300, 200, 40, "继续游戏");
    resumeButton->SetOnClick([]() {
        // 继续游戏
    });
    menu->AddElement(resumeButton);
    
    auto mainMenuButton = CreateButton(540, 360, 200, 40, "返回主菜单");
    mainMenuButton->SetOnClick([]() {
        // 返回主菜单
    });
    menu->AddElement(mainMenuButton);
    
    return menu;
}

std::shared_ptr<Panel> UIManager::CreateRankingBoard() {
    auto board = CreatePanel(340, 110, 600, 500);
    board->SetBackgroundColor({200, 200, 200, 230});
    
    auto title = CreateLabel(640, 140, "排行榜");
    title->SetAlignment(Label::ALIGN_CENTER);
    title->SetFontSize(24);
    board->AddElement(title);
    
    // 这里应该从服务器获取排行榜数据
    for (int i = 0; i < 10; ++i) {
        auto rankText = CreateLabel(360, 200 + i * 30, 
            "第" + std::to_string(i+1) + "名: 玩家" + std::to_string(i+1) + " - CEO - ¥99999");
        board->AddElement(rankText);
    }
    
    auto closeButton = CreateButton(540, 540, 200, 40, "关闭");
    closeButton->SetOnClick([]() {
        // 关闭排行榜
    });
    board->AddElement(closeButton);
    
    return board;
} 