#include "network/server.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <iostream>

GameServer::GameServer(int port)
    : mPort(port)
    , mServerFd(-1)
    , mEpollFd(-1)
    , mIsRunning(false)
    , mSharedMemory(nullptr)
    , mSharedMemoryFd(-1)
{
}

bool GameServer::Initialize() {
    // 创建服务器socket
    mServerFd = socket(AF_INET, SOCK_STREAM, 0);
    if (mServerFd < 0) {
        std::cerr << "创建socket失败" << std::endl;
        return false;
    }
    
    // 设置非阻塞
    int flags = fcntl(mServerFd, F_GETFL, 0);
    fcntl(mServerFd, F_SETFL, flags | O_NONBLOCK);
    
    // 绑定地址
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(mPort);
    addr.sin_addr.s_addr = INADDR_ANY;
    
    if (bind(mServerFd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        std::cerr << "绑定端口失败" << std::endl;
        return false;
    }
    
    // 监听连接
    if (listen(mServerFd, SOMAXCONN) < 0) {
        std::cerr << "监听失败" << std::endl;
        return false;
    }
    
    // 创建epoll实例
    mEpollFd = epoll_create1(0);
    if (mEpollFd < 0) {
        std::cerr << "创建epoll失败" << std::endl;
        return false;
    }
    
    // 添加服务器socket到epoll
    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.fd = mServerFd;
    if (epoll_ctl(mEpollFd, EPOLL_CTL_ADD, mServerFd, &ev) < 0) {
        std::cerr << "添加服务器socket到epoll失败" << std::endl;
        return false;
    }
    
    // 初始化共享内存
    InitSharedMemory();
    
    // 初始化进程池
    InitProcessPool();
    
    mIsRunning = true;
    return true;
}

void GameServer::Run() {
    while (mIsRunning) {
        int nfds = epoll_wait(mEpollFd, mEvents, MAX_EVENTS, -1);
        
        for (int i = 0; i < nfds; i++) {
            if (mEvents[i].data.fd == mServerFd) {
                HandleNewConnection();
            } else {
                HandleClientMessage(mEvents[i].data.fd);
            }
        }
        
        UpdateGameState();
        BroadcastGameState();
    }
}

void GameServer::HandleNewConnection() {
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    int clientFd = accept(mServerFd, (struct sockaddr*)&client_addr, &client_len);
    if (clientFd < 0) {
        return;
    }
    
    // 设置非阻塞
    int flags = fcntl(clientFd, F_GETFL, 0);
    fcntl(clientFd, F_SETFL, flags | O_NONBLOCK);
    
    // 添加到epoll
    struct epoll_event ev;
    ev.events = EPOLLIN | EPOLLET;
    ev.data.fd = clientFd;
    epoll_ctl(mEpollFd, EPOLL_CTL_ADD, clientFd, &ev);
    
    // 创建客户端会话
    mClients[clientFd] = std::make_shared<ClientSession>(clientFd);
    
    // 分配给进程池中的进程
    AssignClientToProcess(clientFd);
}

void GameServer::InitSharedMemory() {
    // 创建共享内存
    mSharedMemoryFd = shm_open("/game_state", O_CREAT | O_RDWR, 0666);
    if (mSharedMemoryFd < 0) {
        std::cerr << "创建共享内存失败" << std::endl;
        return;
    }
    
    // 设置大小
    if (ftruncate(mSharedMemoryFd, 1024 * 1024) < 0) {
        std::cerr << "设置共享内存大小失败" << std::endl;
        return;
    }
    
    // 映射到内存
    mSharedMemory = mmap(NULL, 1024 * 1024, PROT_READ | PROT_WRITE, MAP_SHARED, mSharedMemoryFd, 0);
    if (mSharedMemory == MAP_FAILED) {
        std::cerr << "映射共享内存失败" << std::endl;
        return;
    }
}

void GameServer::InitProcessPool() {
    for (int i = 0; i < PROCESS_POOL_SIZE; i++) {
        pid_t pid = fork();
        
        if (pid == 0) {
            // 子进程
            while (true) {
                // 处理分配给该进程的客户端
            }
            exit(0);
        }
    }
} 