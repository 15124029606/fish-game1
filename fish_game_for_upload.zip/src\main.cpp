#include "game.h"
#include <iostream>

int main(int argc, char* argv[]) {
    try {
        Game game;
        
        if (!game.Initialize()) {
            std::cerr << "游戏初始化失败!" << std::endl;
            return 1;
        }

        game.Run();
        game.Shutdown();
        
        return 0;
    }
    catch (const std::exception& e) {
        std::cerr << "发生错误: " << e.what() << std::endl;
        return 1;
    }
} 