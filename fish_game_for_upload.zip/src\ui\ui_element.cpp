#include "ui/ui_element.h"

UIElement::UIElement(int x, int y, int width, int height)
    : mX(x)
    , mY(y)
    , mWidth(width)
    , mHeight(height)
    , mIsVisible(true)
    , mIsHovered(false)
    , mIsPressed(false)
{
}

bool UIElement::ContainsPoint(int x, int y) const {
    return x >= mX && x < mX + mWidth &&
           y >= mY && y < mY + mHeight;
}

bool UIElement::HandleEvent(const SDL_Event& event) {
    if (!mIsVisible) return false;

    switch (event.type) {
        case SDL_MOUSEMOTION: {
            bool wasHovered = mIsHovered;
            mIsHovered = ContainsPoint(event.motion.x, event.motion.y);
            return wasHovered != mIsHovered;
        }
        
        case SDL_MOUSEBUTTONDOWN: {
            if (event.button.button == SDL_BUTTON_LEFT) {
                if (ContainsPoint(event.button.x, event.button.y)) {
                    mIsPressed = true;
                    return true;
                }
            }
            break;
        }
        
        case SDL_MOUSEBUTTONUP: {
            if (event.button.button == SDL_BUTTON_LEFT) {
                bool wasPressed = mIsPressed;
                mIsPressed = false;
                return wasPressed;
            }
            break;
        }
    }
    
    return false;
}

void UIElement::Update(float deltaTime) {
    // 基类不需要更新逻辑
}

void UIElement::Render(SDL_Renderer* renderer) {
    // 基类不需要渲染逻辑
} 