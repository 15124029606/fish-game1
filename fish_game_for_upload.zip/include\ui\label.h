#pragma once

#include "ui_element.h"

class Label : public UIElement {
public:
    Label(int x, int y, const std::string& text);
    
    // 文本设置
    void SetText(const std::string& text) { mText = text; }
    void SetColor(SDL_Color color) { mTextColor = color; }
    void SetFontSize(int size) { mFontSize = size; }
    void SetAlignment(int align) { mAlignment = align; }
    
    // 重写基类方法
    void Render(SDL_Renderer* renderer) override;

    // 对齐方式
    static const int ALIGN_LEFT = 0;
    static const int ALIGN_CENTER = 1;
    static const int ALIGN_RIGHT = 2;

private:
    std::string mText;
    SDL_Color mTextColor;
    int mFontSize;
    int mAlignment;
}; 