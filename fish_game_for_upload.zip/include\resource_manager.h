#pragma once

#include <SDL2/SDL.h>
#include <string>
#include <unordered_map>
#include <memory>

class ResourceManager {
public:
    static ResourceManager& Instance();
    
    bool Initialize(SDL_Renderer* renderer);
    void Shutdown();
    
    // 贴图加载和获取
    SDL_Texture* GetTexture(const std::string& name);
    bool LoadTexture(const std::string& name, const std::string& filepath);
    
    // 音效加载和播放
    bool LoadSound(const std::string& name, const std::string& filepath);
    void PlaySound(const std::string& name);

private:
    ResourceManager() = default;
    ~ResourceManager() = default;
    
    SDL_Renderer* mRenderer;
    std::unordered_map<std::string, SDL_Texture*> mTextures;
    std::unordered_map<std::string, Mix_Chunk*> mSounds;
}; 