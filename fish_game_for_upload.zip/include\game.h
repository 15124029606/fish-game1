#pragma once

#include <SDL2/SDL.h>
#include <memory>
#include <vector>
#include "player.h"
#include "entity.h"

class Game {
public:
    Game();
    ~Game();

    bool Initialize();
    void Run();
    void Shutdown();

private:
    void ProcessInput();
    void Update();
    void Render();
    
    // SDL相关
    SDL_Window* mWindow;
    SDL_Renderer* mRenderer;
    bool mIsRunning;
    
    // 游戏状态
    std::vector<std::shared_ptr<Player>> mPlayers;
    std::vector<std::shared_ptr<Entity>> mEntities;
    
    // 游戏配置
    static const int SCREEN_WIDTH = 1280;
    static const int SCREEN_HEIGHT = 720;
    static const char* GAME_TITLE = "摸鱼射击游戏";
}; 