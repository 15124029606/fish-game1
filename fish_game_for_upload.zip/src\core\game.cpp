#include "game.h"
#include <iostream>
#include <algorithm>

Game::Game()
    : mWindow(nullptr)
    , mRenderer(nullptr)
    , mIsRunning(false)
{
}

Game::~Game() {
    Shutdown();
}

bool Game::Initialize() {
    // 初始化SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "SDL初始化失败: " << SDL_GetError() << std::endl;
        return false;
    }
    
    // 创建窗口
    mWindow = SDL_CreateWindow(
        GAME_TITLE,
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        SCREEN_WIDTH,
        SCREEN_HEIGHT,
        SDL_WINDOW_SHOWN
    );
    
    if (!mWindow) {
        std::cerr << "窗口创建失败: " << SDL_GetError() << std::endl;
        return false;
    }
    
    // 创建渲染器
    mRenderer = SDL_CreateRenderer(
        mWindow,
        -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
    );
    
    if (!mRenderer) {
        std::cerr << "渲染器创建失败: " << SDL_GetError() << std::endl;
        return false;
    }
    
    mIsRunning = true;
    return true;
}

void Game::Run() {
    uint32_t lastTime = SDL_GetTicks();
    
    while (mIsRunning) {
        uint32_t currentTime = SDL_GetTicks();
        float deltaTime = (currentTime - lastTime) / 1000.0f;
        lastTime = currentTime;
        
        ProcessInput();
        Update(deltaTime);
        Render();
    }
}

void Game::Shutdown() {
    if (mRenderer) {
        SDL_DestroyRenderer(mRenderer);
        mRenderer = nullptr;
    }
    
    if (mWindow) {
        SDL_DestroyWindow(mWindow);
        mWindow = nullptr;
    }
    
    SDL_Quit();
}

void Game::ProcessInput() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                mIsRunning = false;
                break;
                
            case SDL_KEYDOWN:
                // 处理键盘输入
                break;
                
            case SDL_MOUSEBUTTONDOWN:
                // 处理鼠标点击
                break;
        }
    }
    
    // 处理持续按键状态
    const Uint8* state = SDL_GetKeyboardState(nullptr);
    if (state[SDL_SCANCODE_W] || state[SDL_SCANCODE_UP]) {
        // 向上移动
    }
    if (state[SDL_SCANCODE_S] || state[SDL_SCANCODE_DOWN]) {
        // 向下移动
    }
    if (state[SDL_SCANCODE_A] || state[SDL_SCANCODE_LEFT]) {
        // 向左移动
    }
    if (state[SDL_SCANCODE_D] || state[SDL_SCANCODE_RIGHT]) {
        // 向右移动
    }
}

void Game::Update(float deltaTime) {
    // 更新所有实体
    for (auto& player : mPlayers) {
        player->Update(deltaTime);
    }
    
    for (auto& entity : mEntities) {
        entity->Update(deltaTime);
    }
    
    // 检测碰撞
    for (auto& player : mPlayers) {
        for (auto& entity : mEntities) {
            if (player->CollidesWith(entity.get())) {
                // 处理碰撞
                switch (entity->GetType()) {
                    case EntityType::PROJECT:
                        // 增加金钱
                        break;
                    case EntityType::BOSS:
                        // 升级职级
                        break;
                    case EntityType::FISH:
                        // 恢复体力
                        break;
                }
            }
        }
    }
}

void Game::Render() {
    // 清空屏幕
    SDL_SetRenderDrawColor(mRenderer, 0, 0, 0, 255);
    SDL_RenderClear(mRenderer);
    
    // 渲染所有实体
    for (auto& entity : mEntities) {
        entity->Render(mRenderer);
    }
    
    // 渲染所有玩家
    for (auto& player : mPlayers) {
        player->Render(mRenderer);
    }
    
    // 更新屏幕
    SDL_RenderPresent(mRenderer);
} 