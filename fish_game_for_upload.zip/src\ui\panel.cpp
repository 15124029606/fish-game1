#include "ui/panel.h"
#include <algorithm>

Panel::Panel(int x, int y, int width, int height)
    : UIElement(x, y, width, height)
    , mBorderWidth(1)
{
    mBackgroundColor = {200, 200, 200, 200};  // 半透明灰色
    mBorderColor = {100, 100, 100, 255};      // 深灰色边框
}

void Panel::AddElement(std::shared_ptr<UIElement> element) {
    if (element) {
        mElements.push_back(element);
    }
}

void Panel::RemoveElement(std::shared_ptr<UIElement> element) {
    auto it = std::find(mElements.begin(), mElements.end(), element);
    if (it != mElements.end()) {
        mElements.erase(it);
    }
}

void Panel::ClearElements() {
    mElements.clear();
}

bool Panel::HandleEvent(const SDL_Event& event) {
    if (!mIsVisible) return false;
    
    // 先处理子元素的事件
    bool handled = false;
    for (auto it = mElements.rbegin(); it != mElements.rend(); ++it) {
        if ((*it)->HandleEvent(event)) {
            handled = true;
            break;
        }
    }
    
    // 如果子元素没有处理事件，则处理面板自身的事件
    if (!handled) {
        handled = UIElement::HandleEvent(event);
    }
    
    return handled;
}

void Panel::Update(float deltaTime) {
    if (!mIsVisible) return;
    
    // 更新所有子元素
    for (auto& element : mElements) {
        element->Update(deltaTime);
    }
}

void Panel::Render(SDL_Renderer* renderer) {
    if (!mIsVisible) return;
    
    // 绘制面板背景
    SDL_SetRenderDrawColor(renderer,
        mBackgroundColor.r, mBackgroundColor.g,
        mBackgroundColor.b, mBackgroundColor.a);
    
    SDL_Rect rect = {mX, mY, mWidth, mHeight};
    SDL_RenderFillRect(renderer, &rect);
    
    // 绘制边框
    if (mBorderWidth > 0) {
        SDL_SetRenderDrawColor(renderer,
            mBorderColor.r, mBorderColor.g,
            mBorderColor.b, mBorderColor.a);
        
        for (int i = 0; i < mBorderWidth; ++i) {
            SDL_Rect borderRect = {
                mX + i,
                mY + i,
                mWidth - 2 * i,
                mHeight - 2 * i
            };
            SDL_RenderDrawRect(renderer, &borderRect);
        }
    }
    
    // 绘制所有子元素
    for (auto& element : mElements) {
        element->Render(renderer);
    }
} 