#pragma once

#include "ui_element.h"
#include <vector>

class Panel : public UIElement {
public:
    Panel(int x, int y, int width, int height);
    
    // 子元素管理
    void AddElement(std::shared_ptr<UIElement> element);
    void RemoveElement(std::shared_ptr<UIElement> element);
    void ClearElements();
    
    // 设置样式
    void SetBackgroundColor(SDL_Color color) { mBackgroundColor = color; }
    void SetBorderColor(SDL_Color color) { mBorderColor = color; }
    void SetBorderWidth(int width) { mBorderWidth = width; }
    
    // 重写基类方法
    bool HandleEvent(const SDL_Event& event) override;
    void Update(float deltaTime) override;
    void Render(SDL_Renderer* renderer) override;

private:
    std::vector<std::shared_ptr<UIElement>> mElements;
    SDL_Color mBackgroundColor;
    SDL_Color mBorderColor;
    int mBorderWidth;
}; 