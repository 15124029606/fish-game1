#include "player.h"
#include <algorithm>

Player::Player(const std::string& name)
    : mName(name)
    , mRank(Rank::INTERN)
    , mMoney(0)
    , mEnergy(MAX_ENERGY)
    , mShootCooldown(0.0f)
{
    mType = EntityType::PLAYER;
    mWidth = 48.0f;  // 玩家碰撞箱稍大一些
    mHeight = 48.0f;
}

void Player::Shoot() {
    if (!CanShoot()) return;
    
    // 根据职级确定射击消耗
    int energyCost = 0;
    switch (mRank) {
        case Rank::INTERN:
            energyCost = 5;
            mShootCooldown = SHOOT_COOLDOWN_INTERN;
            break;
        case Rank::MANAGER:
            energyCost = 3;
            mShootCooldown = SHOOT_COOLDOWN_MANAGER;
            break;
        case Rank::CEO:
            energyCost = 1;
            mShootCooldown = SHOOT_COOLDOWN_CEO;
            break;
    }
    
    mEnergy = std::max(0, mEnergy - energyCost);
}

void Player::Move(float dx, float dy) {
    float speed = IsMovementReduced() ? 100.0f : 200.0f;
    
    // 对角线移动时需要标准化速度向量
    float length = std::sqrt(dx*dx + dy*dy);
    if (length > 0) {
        dx /= length;
        dy /= length;
    }
    
    mVelX = dx * speed;
    mVelY = dy * speed;
}

void Player::Update(float deltaTime) {
    Entity::Update(deltaTime);
    
    // 更新射击冷却
    if (mShootCooldown > 0) {
        mShootCooldown = std::max(0.0f, mShootCooldown - deltaTime);
    }
    
    // 缓慢恢复体力
    if (mEnergy < MAX_ENERGY) {
        mEnergy = std::min(MAX_ENERGY, mEnergy + static_cast<int>(deltaTime * 5));
    }
} 