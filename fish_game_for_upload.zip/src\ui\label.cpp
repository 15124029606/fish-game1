#include "ui/label.h"
#include <SDL2/SDL_ttf.h>

Label::Label(int x, int y, const std::string& text)
    : UIElement(x, y, 0, 0)  // 宽高将根据文本自动计算
    , mText(text)
    , mFontSize(16)
    , mAlignment(ALIGN_LEFT)
{
    mTextColor = {0, 0, 0, 255};  // 默认黑色文本
}

void Label::Render(SDL_Renderer* renderer) {
    if (!mIsVisible || mText.empty()) return;
    
    // 加载字体
    TTF_Font* font = TTF_OpenFont("assets/fonts/default.ttf", mFontSize);
    if (!font) return;
    
    // 渲染文本
    SDL_Surface* surface = TTF_RenderText_Blended(font, mText.c_str(), mTextColor);
    if (surface) {
        SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
        if (texture) {
            // 更新标签尺寸
            mWidth = surface->w;
            mHeight = surface->h;
            
            // 根据对齐方式计算渲染位置
            int renderX = mX;
            switch (mAlignment) {
                case ALIGN_CENTER:
                    renderX = mX - mWidth / 2;
                    break;
                case ALIGN_RIGHT:
                    renderX = mX - mWidth;
                    break;
            }
            
            SDL_Rect destRect = {renderX, mY, mWidth, mHeight};
            SDL_RenderCopy(renderer, texture, nullptr, &destRect);
            SDL_DestroyTexture(texture);
        }
        SDL_FreeSurface(surface);
    }
    
    TTF_CloseFont(font);
} 